#!/bin/bash

obj="Biomass_SLI"
inocule=0.1
ns=100	# steps
ts=60	# minutes
h=`echo "scale=2; $ts/60" | bc -l`
h=1
verbose=2
constraints=dag_mnl_aa
#constraints=""
med=NMMP+mnl

#rates=rates_full
#rates=rates
#rates=dag_dyn_rates
#rates=dag_full_rates
rates=dag_delta_rates.105	# 85 steps 
rates=dag_delta_rates.107	# 85 steps 
rates=dag_delta_rates

deltas=deltas

# -u -> madfba, default function, -a -> adfba
[ -z $1 ] && function=-u
[ -z $function ] && function=$1

out=obj_Biomass_SLI/Slividans+${constraints}+${rates}@${med}+${deltas}:${h}hx${ns}/
if [ -d $out ] ; then
    rm -rf $out
fi

./adynFBA.R -m Slividans -g "$obj" -b "$obj" $function -V $verbose \
    -c "$constraints" -n $med -t $ts -s $ns -i $inocule -e $rates -l $deltas \
|& tee LOG

if [ -s $out/adfba/*BA-l.png ] ; then
#    display -resize 75% $out/adfba/*.png            # command with imageclick
#    eog --fullscreen --slide-show $out/adfba/*.png   # command linux with gnome desktop eog -> 'Eyes Of Gnome'
    eog --new-instance $out/adfba/*.png   # command linux with gnome desktop eog -> 'Eyes Of Gnome'
fi

if [ -d $out ] ; then
    cp $0 $out/
    cp adynFBA.R $out/
    cp $constraints.* $out/
    cp $med.* $out/
    cp $rates.* $out/
    cp $deltas.* $out/
else
    echo "ERROR: no output generated!"
    exit 1
fi
